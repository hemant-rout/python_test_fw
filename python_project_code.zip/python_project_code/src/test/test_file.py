import pytest
import pandas as pd
import numpy as np


def test_mismatching_res(get_df):
    df = get_df.copy()
    df.drop(['result'], axis=1, inplace=True)
    df["result"] = [25, 26, 24, 28]

    res = get_df.merge(df, on=["id", "Name", "result"], how="outer")
    mismatch_count = res.isna().sum().sum()
    res.replace(np.nan, -999, inplace=True)
    print(res.head())
    assert mismatch_count == 0


def test_matching_res(get_df):
    df = get_df.copy()
    df.drop(['result'], axis=1, inplace=True)
    df["result"] = [25, 26, 24, 23]

    res = get_df.merge(df, on=["id", "Name", "result"], how="outer")
    mismatch_count = res.isna().sum().sum()
    res.replace(np.nan, -999, inplace=True)
    print(res.head())
    assert mismatch_count == 0
