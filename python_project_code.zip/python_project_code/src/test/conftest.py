import pytest
import pandas as pd


@pytest.fixture
def get_df():
    data = {'id': [1, 2, 3, 4],
            'Name': ['Tom', 'nick', 'krish', 'jack'],
            'Age': [20, 21, 19, 18],
            'result': [25, 26, 24, 23]
            }
    df = pd.DataFrame(data)
    return df